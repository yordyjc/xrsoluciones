<?php $__env->startSection('title'); ?>
Nuevo Administrador
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="card-body">
	<form action="<?php echo e(url('/admin/clientes')); ?>" method="post" enctype="multipart/form-data">
		<?php echo csrf_field(); ?>
        <div class="form-group row">
            <label class="col-md-4 col-form-label" for="tipo">
                Estado
            </label>
            <div class="col-md-8 form-radio">
                <div class="form-check-inline my-1">
                    <label>
                    <input type="radio" name="estado" id="estado" value="1" checked="checked">
                    <i class="helper"></i>Activo
                    </label>
                </div>
                <div class="form-check-inline my-1">
                    <label>
                    <input type="radio" name="estado" id="estado" value="0">
                    <i class="helper"></i>Suspendido
                    </label>
                </div>
            </div>
        </div>
		<div class="form-group row <?php echo e($errors->has('nombres') ? ' has-warning' : ''); ?>">
            <label for="example-text-input" class="col-sm-4 col-form-label" for="nombres">
                Nombres o razon social
            </label>
            <div class="col-sm-8">
            	<input class="form-control <?php echo e($errors->has('nombres') ? ' form-control-warning' : ''); ?>" type="text" id="nombres" name="nombres" value="<?php echo e(old('nombres')); ?>" >
                <?php if($errors->has('nombres')): ?>
                    <div class="col-form-label">
                        <?php echo e($errors->first('nombres')); ?>

                    </div>
                <?php endif; ?>
            </div>
        </div>
        <div class="form-group row <?php echo e($errors->has('email') ? ' has-warning' : ''); ?>">
            <label for="example-text-input" class="col-sm-4 col-form-label" for="email">
                Email
            </label>
            <div class="col-sm-8">
            	<input class="form-control <?php echo e($errors->has('email') ? ' form-control-warning' : ''); ?>" type="text" id="email" name="email" value="<?php echo e(old('email')); ?>">
                <?php if($errors->has('email')): ?>
                    <div class="col-form-label">
                        <?php echo e($errors->first('email')); ?>

                    </div>
                <?php endif; ?>
            </div>
        </div>

        <div class="form-group row <?php echo e($errors->has('doc') ? ' has-warning' : ''); ?>">
            <label for="example-text-input" class="col-sm-4 col-form-label" for="doc">
                DNI o RUC
            </label>
            <div class="col-sm-8">
            	<input class="form-control <?php echo e($errors->has('doc') ? ' form-control-warning' : ''); ?>" type="text" id="doc" name="doc" value="<?php echo e(old('doc')); ?>">
                <?php if($errors->has('doc')): ?>
                    <div class="col-form-label">
                        <?php echo e($errors->first('doc')); ?>

                    </div>
                <?php endif; ?>
            </div>
        </div>
        <div class="form-group row <?php echo e($errors->has('cel') ? ' has-warning' : ''); ?>">
            <label for="example-text-input" class="col-sm-4 col-form-label" for="cel">
                Cel.
            </label>
            <div class="col-sm-8">
            	<input class="form-control <?php echo e($errors->has('cel') ? ' form-control-warning' : ''); ?>" type="text" id="cel" name="cel" value="<?php echo e(old('cel')); ?>">
                <?php if($errors->has('cel')): ?>
                    <div class="col-form-label">
                        <?php echo e($errors->first('cel')); ?>

                    </div>
                <?php endif; ?>
            </div>
        </div>

        <div class="form-group row <?php echo e($errors->has('direccion') ? ' has-warning' : ''); ?>">
            <label for="example-text-input" class="col-sm-4 col-form-label" for="direccion">
                Dirección
            </label>
            <div class="col-sm-8">
            	<input class="form-control <?php echo e($errors->has('direccion') ? ' form-control-warning' : ''); ?>" type="text" id="direccion" name="direccion" value="<?php echo e(old('direccion')); ?>">
                <?php if($errors->has('direccion')): ?>
                    <div class="col-form-label">
                        <?php echo e($errors->first('direccion')); ?>

                    </div>
                <?php endif; ?>
            </div>
        </div>

        <div class="form-group row <?php echo e($errors->has('observaciones') ? ' has-warning' : ''); ?>">
            <label for="example-text-input" class="col-sm-4 col-form-label" for="observaciones">
                Observaciones
            </label>
            <div class="col-sm-8">
            	<input class="form-control <?php echo e($errors->has('observaciones') ? ' form-control-warning' : ''); ?>" type="text" id="observaciones" name="observaciones" value="<?php echo e(old('observaciones')); ?>">
                <?php if($errors->has('observaciones')): ?>
                    <div class="col-form-label">
                        <?php echo e($errors->first('observaciones')); ?>

                    </div>
                <?php endif; ?>
            </div>
        </div>

        <br>
        <br>
        <div class="col-sm-10 offset-sm-1">
            <div class="form-group row text-center">
                <div class="col-sm-6">
                    <button type="submit" class="btn btn-lg btn-warning waves-effect waves-light">
                        <i class="icofont icofont-save"></i> Guardar
                    </button>
                </div>
                <div class="col-sm-6">
                    <button type="reset" class="btn btn-lg btn-danger waves-effect waves-light">
                        <i class="icofont icofont-save"></i> Borrar
                    </button>
                </div>
            </div>
        </div>
	</form>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\yonei\Documents\projects\XRSoluciones\resources\views/admin/clientes/crear.blade.php ENDPATH**/ ?>