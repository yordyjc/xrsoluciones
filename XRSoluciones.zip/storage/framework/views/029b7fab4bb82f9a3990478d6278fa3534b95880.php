<?php $__env->startSection('title'); ?>
Lista de ordenes de trabajo
<?php $__env->stopSection(); ?>
<?php
use Carbon\Carbon;
setlocale(LC_TIME, 'es_ES.UTF-8');
Carbon::setLocale('es');

function concatenar($numero){
    $n=strlen($numero);
    if ($n==1) {
        $a='0000'.$numero;
    }
    else if ($n==2) {
        $a='000'.$numero;
    }
    else if ($n==3) {
        $a='00'.$numero;
    }
    else if ($n==4) {
        $a='0'.$numero;
    }
    else{
        $a=$numero;
    }
    return $a;
}
?>

<?php $__env->startSection('content'); ?>
    <div class="card-header ">
        <div class="text-right">
            <a href="<?php echo e(url('/admin/ordenes/create')); ?>" class="btn btn-outline-primary waves-effect waves-light btn-lg"> <i class="typcn typcn-user-add"></i> Agregar orden de trabajo</a>
        </div>
    </div>
	<div class="card-body">
		<table id="datatable2" class="table table-bordered dt-responsive nowrap" style="border-collapse: collapse; border-spacing: 0; width: 100%;"	>
	        <thead>
	            <tr>
	              <th>Código</th>
	              <th>Cliente</th>
	              <th>Tipo de servicio</th>
	              <th>Fecha de entrega</th>
	              <th>Check List</th>
                  <th>Agregados</th>
	              <th>Servicios</th>
                  <th>Informe</th>
                  <th>Estado</th>
                  <th>Acciones</th>
	            </tr>
	          </thead>
	          <tbody>
	          	<?php if(count($ordenes) >0 ): ?>
		          	<?php $__currentLoopData = $ordenes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orden): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e(concatenar($orden->id)); ?></td>
                            <td><?php echo e($orden->cliente->nombres); ?>

                            <p class="text-muted m-b-0">Registrado el <?php echo e(Carbon::parse($orden->created_at)->format('d/m/Y h:i a')); ?></p>
                            </td>
                            <td><?php echo e($orden->categoria->nombre); ?></td>
                            <td><?php echo e($orden->entrega); ?></td>
                            <td>
                                <?php if(count($orden->checklists) >0 ): ?>
                                    <?php $__currentLoopData = $orden->checklists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $checklist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <p><?php echo e($checklist->tipo); ?></p>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </td>

                            <td>
                                <?php if(count($orden->documentos) >0 ): ?>
                                    <?php $__currentLoopData = $orden->documentos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $documentos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <p><?php echo e($documentos->nombre); ?></p>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </td>

                            <td>
                                <?php if(count($orden->servicios) >0 ): ?>
                                    <?php $__currentLoopData = $orden->servicios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $servicios): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <p><?php echo e($servicios->nombre); ?></p>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </td>

                            <td>
                                <a href="#">
                                    <i class="feather icon-download f-w-600 icon-negro" data-toggle="tooltip" data-placement="left" data-original-title="Generar informe"></i>
                                </a>
                            </td>



                            <?php if($orden->estado == 1): ?>
                            <td class="text-center"><h5><span class="badge badge-success">Concluido</span></h5></td>
                            <?php else: ?>
                            <td class="text-center"><h5><span class="badge badge-danger">En proceso</span></h5></td>
                            <?php endif; ?>
                            <td class="text-center">

                                <a href="#">
                                    <i class="icon feather icon-plus-circle f-w-600 icon-azul" data-toggle="tooltip" data-placement="left" data-original-title="Agregar chofer"></i>
                                </a>
                                <a href="<?php echo e(url('/admin/ordenes/'.$orden->id)); ?>">
                                    <i class="icon feather icon-external-link f-w-600 icon-azul" data-toggle="tooltip" data-placement="left" data-original-title="ver detalles"></i>
                                </a>

                                <a href="#">
                                    <i class="feather icon-edit f-w-600 icon-azul" data-toggle="tooltip" data-placement="left" data-original-title="Editar"></i>
                                </a>

                                <a href="#" onclick="eliminarModal(<?php echo e($orden->id); ?>)"data-toggle="modal" data-target="#eliminarModal">
                                    <i class="icon feather icon-trash-2 f-w-600 icon-rojo" data-toggle="tooltip" data-placement="left" data-original-title="Eliminar"></i>
                                </a>

                            </td>
                        </tr>
		            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		            <div class="modal fade" id="eliminarModal" tabindex="-1" role="dialog">
                        <div class="modal-dialog" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title">¡Alto!</h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <form action="" method="POST" id="form-modal">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <div class="modal-body">
                                        <p>Esta acción no podrá deshacerse. ¿Quieres continuar?</p>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="submit" class="btn btn-danger">
                                            <i class="icofont icofont-ui-delete"></i>Sí, suspender cliente
                                        </button>
                                        <button class="btn btn-primary" data-dismiss="modal">
                                            <i class="icofont icofont-circled-left"></i> Cancelar
                                        </button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
	            <?php endif; ?>
	        </tbody>
	    </table>
	</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script type="text/javascript">
    $(document).ready( function () {
        $('#datatable2').DataTable({
            "paging":    true,
            "info":      true,
            // "searching": false,
            "language": {
                "lengthMenu": "Mostrar  _MENU_  registros por página",
                "zeroRecords": "Ningún registro encontrado",
                "info": "Página _PAGE_ de _PAGES_",
                "infoEmpty": "Sin registros",
                "infoFiltered": "(búsqueda realizada en _MAX_  registros)",
                "search": "Buscar: ",
                "paginate": {
                    "previous": "Anterior",
                    "next": "Siguiente"
                }
            },
            "order":[]
        });
    });
    function eliminarModal(id){
        var formModal=$("#form-modal");
        var url=location.origin;
        var path=location.pathname
        formModal.attr('action',url+path+'/'+id);
    }
  </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\yonei\Documents\projects\XRSoluciones\resources\views/admin/ordenes/index.blade.php ENDPATH**/ ?>