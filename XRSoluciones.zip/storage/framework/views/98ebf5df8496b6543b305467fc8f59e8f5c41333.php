<?php $__env->startSection('title'); ?>
Lista de clientes
<?php $__env->stopSection(); ?>
<?php
use Carbon\Carbon;
setlocale(LC_TIME, 'es_ES.UTF-8');
Carbon::setLocale('es');

function concatenar($numero){
    $n=strlen($numero);
    if ($n==1) {
        $a='0000'.$numero;
    }
    else if ($n==2) {
        $a='000'.$numero;
    }
    else if ($n==3) {
        $a='00'.$numero;
    }
    else if ($n==4) {
        $a='0'.$numero;
    }
    else{
        $a=$numero;
    }
    return $a;
}
?>

<?php $__env->startSection('content'); ?>
    <div class="card-header ">
        <div class="text-right">
            <a href="<?php echo e(url('/admin/clientes/create')); ?>" class="btn btn-outline-primary waves-effect waves-light btn-lg"> <i class="typcn typcn-user-add"></i> Agregar cliente</a>
        </div>
    </div>
	<div class="card-body">
		<table id="datatable2" class="table table-bordered dt-responsive nowrap" style="border-collapse: collapse; border-spacing: 0; width: 100%;"	>
	        <thead>
	            <tr>
	              <th>Nº</th>
	              <th>Nombres o Razon social</th>
	              <th>Correo</th>
	              <th>DNI 0 RUC</th>
	              <th>cel</th>
                  <th>Estado</th>
	              <th>Acciones</th>
	            </tr>
	          </thead>
	          <tbody>
	          	<?php if(count($clientes) >0 ): ?>
		          	<?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e(concatenar($cliente->id)); ?></td>
                            <td><?php echo e($cliente->nombres); ?>

                            <p class="text-muted m-b-0">Registrado el <?php echo e(Carbon::parse($cliente->created_at)->format('d/m/Y h:i a')); ?></p>
                            </td>
                            <td><?php echo e($cliente->email); ?></td>
                            <td><?php echo e($cliente->doc); ?></td>
                            <td><?php echo e($cliente->cel); ?></td>
                            <?php if($cliente->estado == 1): ?>
                            <td class="text-center"><h5><span class="badge badge-success">Activo</span></h5></td>
                            <?php else: ?>
                            <td class="text-center"><h5><span class="badge badge-danger">Suspendido</span></h5></td>
                            <?php endif; ?>
                            <td class="text-center">
                                <?php if($cliente->estado==1): ?>
                                <a href="<?php echo e(url('/admin/conductores/'.$cliente->id)); ?>">
                                    <i class="icon feather icon-plus-circle f-w-600 icon-azul" data-toggle="tooltip" data-placement="left" data-original-title="Agregar chofer"></i>
                                </a>
                                <a href="<?php echo e(url('/admin/clientes/'.$cliente->id)); ?>">
                                    <i class="feather icon-eye f-w-600 icon-verde" data-toggle="tooltip" data-placement="left" data-original-title="Ver detalles"></i>
                                </a>
                                <?php endif; ?>
                                <a href="<?php echo e(url('/admin/clientes/'.$cliente->id.'/edit')); ?>">
                                    <i class="feather icon-edit f-w-600 icon-azul" data-toggle="tooltip" data-placement="left" data-original-title="Editar"></i>
                                </a>
                                <?php if($cliente->estado==1): ?>
                                <a href="#" onclick="eliminarModal(<?php echo e($cliente->id); ?>)"data-toggle="modal" data-target="#eliminarModal">
                                    <i class="icon feather icon-trash-2 f-w-600 icon-rojo" data-toggle="tooltip" data-placement="left" data-original-title="Eliminar"></i>
                                </a>
                                <?php endif; ?>
                            </td>
                        </tr>
		            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		            <div class="modal fade" id="eliminarModal" tabindex="-1" role="dialog">
                        <div class="modal-dialog" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title">¡Alto!</h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <form action="" method="POST" id="form-modal">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <div class="modal-body">
                                        <p>Esta acción no podrá deshacerse. ¿Quieres continuar?</p>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="submit" class="btn btn-danger">
                                            <i class="icofont icofont-ui-delete"></i>Sí, suspender cliente
                                        </button>
                                        <button class="btn btn-primary" data-dismiss="modal">
                                            <i class="icofont icofont-circled-left"></i> Cancelar
                                        </button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
	            <?php endif; ?>
	        </tbody>
	    </table>
	</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script type="text/javascript">
    $(document).ready( function () {
        $('#datatable2').DataTable({
            "paging":    true,
            "info":      true,
            // "searching": false,
            "language": {
                "lengthMenu": "Mostrar  _MENU_  registros por página",
                "zeroRecords": "Ningún registro encontrado",
                "info": "Página _PAGE_ de _PAGES_",
                "infoEmpty": "Sin registros",
                "infoFiltered": "(búsqueda realizada en _MAX_  registros)",
                "search": "Buscar: ",
                "paginate": {
                    "previous": "Anterior",
                    "next": "Siguiente"
                }
            },
            "order":[]
        });
    });
    function eliminarModal(id){
        var formModal=$("#form-modal");
        var url=location.origin;
        var path=location.pathname
        formModal.attr('action',url+path+'/'+id);
    }
  </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\yonei\Documents\projects\XRSoluciones\resources\views/admin/clientes/index.blade.php ENDPATH**/ ?>