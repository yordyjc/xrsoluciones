<!DOCTYPE html>
<html>
<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width,initial-scale=1,user-scalable=0,minimal-ui">
  <title>XR Soluciones | <?php echo $__env->yieldContent('title'); ?></title>
  <meta content="Admin Dashboard" name="description">
  <meta content="Mannatthemes" name="author">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <?php echo $__env->make('includes.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php echo $__env->make('includes.data', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  
</head>
<body class="fixed-left">
    <!-- Loader -->
    <div id="preloader">
      <div id="status">
          <div class="spinner"></div>
      </div>
    </div>
    <div id="wrapper">
        <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="content-page">
            <div class="content">
                <?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="page-content-wrapper">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-sm-12">
                                <div class="page-title-box">
                                    <div class="btn-group float-right">
                                        <ol class="breadcrumb hide-phone p-0 m-0">
                                            <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">XR Soluciones</a></li>
                                            <li class="breadcrumb-item active"><?php echo $__env->yieldContent('title'); ?></li>
                                        </ol>
                                    </div>
                                    <h4 class="page-title"><?php echo $__env->yieldContent('title'); ?></h4>
                                </div>
                            </div>  
                        </div>
                  <div class="row">
                      <div class="col-12">
                          <div class="card m-b-30">
                              <?php echo $__env->yieldContent('content'); ?>
                          </div>
                      </div>
                      
                  </div>
                        </div>
                    
                </div>
            </div>
        
            <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        </div>
    </div>
    <?php echo $__env->make('includes.js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html><?php /**PATH C:\Users\yonei\Documents\projects\XRSoluciones\resources\views/layouts/app.blade.php ENDPATH**/ ?>