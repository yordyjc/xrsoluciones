<?php $__env->startSection('title'); ?>
    Perfil de cliente
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php
use Carbon\Carbon;
setlocale(LC_TIME, 'es_ES.UTF-8');
Carbon::setLocale('es');

function concatenar($numero){
    $n=strlen($numero);
    if ($n==1) {
        $a='0000'.$numero;
    }
    else if ($n==2) {
        $a='000'.$numero;
    }
    else if ($n==3) {
        $a='00'.$numero;
    }
    else if ($n==4) {
        $a='0'.$numero;
    }
    else{
        $a=$numero;
    }
    return $a;
}
?>
    <div class="card-header ">
        <div class="text-left">
            <h4 class="mt-0 header-title"><?php echo $__env->yieldContent('title'); ?></h4>
        </div>
    </div>

    <div class="card-body">
        <div class="row">
            <div class="col-sm-6">
                <center><img class="rounded-circle align-top img-thumbnail" src="<?php echo e($cliente->foto ? $cliente->foto : url('assets/images/users/avatar-1.jpg')); ?>" width="300px" height="300px"></center>
            </div>
            <div class="col-sm-6">
                <dl class="dl-horizontal row mt-2">
                    <dt class="col-sm-3">Nombres</dt>
                    <dd class="col-sm-9">
                        <?php echo e($cliente->nombres); ?>

                    </dd>
                    <dt class="col-sm-3">Correo</dt>
                    <dd class="col-sm-9"><?php echo e($cliente->email); ?></dd>

                    <dt class="col-sm-3">Celular</dt>
                    <dd class="col-sm-9"><?php echo e($cliente->cel); ?></dd>

                    <dt class="col-sm-3">Dirección</dt>
                    <dd class="col-sm-9"><?php echo e($cliente->direccion); ?></dd>

                    <dt class="col-sm-3">DNI/RUC</dt>
                    <dd class="col-sm-9"><?php echo e($cliente->doc); ?></dd>

                    <dt class="col-sm-3">Observaciones</dt>
                    <dd class="col-sm-9"><?php echo e($cliente->observaciones); ?></dd>

                    <dt class="col-sm-3">Registrado</dt>
                    <dd class="col-sm-9"><?php echo e(Carbon::parse($cliente->created_at)->format('d \d\e M. \d\e Y')); ?></dd>

                    <dt class="col-sm-3">Modificado</dt>
                    <dd class="col-sm-9"><?php echo e(Carbon::parse($cliente->updated_at)->format('d \d\e M. \d\e Y')); ?></dd>
                    <dd class="col-sm-12 offset-sm-3 text-muted">(<?php echo e(Carbon::parse($cliente->updated_at)->diffForHumans(null, false, false, 2)); ?>)</dd>
                </dl>

            </div>
        </div>
    </div>

    <div class="card-header">
        <div class="text-left">
            <h4 class="mt-0 header-title">Conductores</h4>
        </div>
    </div>
    <div class="card-body">
        <table id="datatable2" class="table table-bordered dt-responsive nowrap" style="border-collapse: collapse; border-spacing: 0; width: 100%;"	>
	        <thead>
	            <tr>
	              <th>Nombres</th>
	              <th>Correo</th>
	              <th>Doc. de identidad</th>
                  <th>Celular</th>
	              <th>Licencia</th>
                  <th>Fecha de caducidad</th>
	              <th>Acciones</th>
	            </tr>
	          </thead>
	          <tbody>
	          	<?php if(count($cliente->conductores) >0 ): ?>
		          	<?php $__currentLoopData = $cliente->conductores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $conductor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($conductor->nombres); ?> <?php echo e($conductor->apellidos); ?>

                            <p class="text-muted m-b-0">Registrado el <?php echo e(Carbon::parse($conductor->created_at)->format('d/m/Y')); ?></p>
                            </td>
                            <td><?php echo e($conductor->email); ?></td>
                            <td><?php echo e($conductor->doc); ?></td>
                            <td><?php echo e($conductor->cel); ?></td>
                            <td class="text-center">
                                <?php switch($conductor->licencia):
                                    case (1): ?>
                                        <span class="badge badge-primary">AI</span>
                                        <?php break; ?>
                                    <?php case (2): ?>
                                        <span class="badge badge-primary">A-IIa</span>
                                        <?php break; ?>
                                    <?php case (3): ?>
                                        <span class="badge badge-primary">A-IIb</span>
                                        <?php break; ?>
                                    <?php case (4): ?>
                                        <span class="badge badge-primary">A-IIIa</span>
                                        <?php break; ?>
                                    <?php case (5): ?>
                                        <span class="badge badge-primary">A-IIIb</span>
                                        <?php break; ?>
                                    <?php case (6): ?>
                                        <span class="badge badge-primary">A-IIIc</span>
                                        <?php break; ?>
                                    <?php case (7): ?>
                                        <span class="badge badge-primary">B-I</span>
                                        <?php break; ?>
                                    <?php case (8): ?>
                                        <span class="badge badge-primary">B-IIa</span>
                                        <?php break; ?>
                                    <?php case (9): ?>
                                        <span class="badge badge-primary">B-IIb</span>
                                        <?php break; ?>
                                    <?php case (10): ?>
                                        <span class="badge badge-primary">B-IIc</span>
                                        <?php break; ?>
                                <?php endswitch; ?>

                            </td>
                            <td><?php echo e(Carbon::parse($conductor->caducidad)->format('d \d\e M. \d\e Y')); ?></td>
                            <td class="text-center">
                                <a href="<?php echo e(url('/admin/conductores/'.$conductor->id.'/edit')); ?>">
                                    <i class="feather icon-edit f-w-600 icon-azul" data-toggle="tooltip" data-placement="left" data-original-title="Editar"></i>
                                </a>
                            </td>
                        </tr>
		            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		            <div class="modal fade" id="eliminarModal" tabindex="-1" role="dialog">
                        <div class="modal-dialog" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title">¡Alto!</h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <form action="" method="POST" id="form-modal">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <div class="modal-body">
                                        <p>Esta acción no podrá deshacerse. ¿Quieres continuar?</p>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="submit" class="btn btn-danger">
                                            <i class="icofont icofont-ui-delete"></i>Sí, suspender cliente
                                        </button>
                                        <button class="btn btn-primary" data-dismiss="modal">
                                            <i class="icofont icofont-circled-left"></i> Cancelar
                                        </button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
	            <?php endif; ?>
	        </tbody>
	    </table>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>
    $(document).ready( function () {
        $('#datatable2').DataTable({
            "paging":    true,
            "info":      true,
            // "searching": false,
            "language": {
                "lengthMenu": "Mostrar  _MENU_  registros por página",
                "zeroRecords": "Ningún registro encontrado",
                "info": "Página _PAGE_ de _PAGES_",
                "infoEmpty": "Sin registros",
                "infoFiltered": "(búsqueda realizada en _MAX_  registros)",
                "search": "Buscar: ",
                "paginate": {
                    "previous": "Anterior",
                    "next": "Siguiente"
                }
            },
            "order":[]
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\yonei\Documents\projects\XRSoluciones\resources\views/admin/clientes/ver.blade.php ENDPATH**/ ?>