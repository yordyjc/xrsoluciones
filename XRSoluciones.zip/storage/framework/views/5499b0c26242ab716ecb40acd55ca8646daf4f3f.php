<?php $__env->startSection('title'); ?>
Nuevo servicio
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<div class="card-body">
	<form action="<?php echo e(url('/admin/servicios')); ?>" method="post" enctype="multipart/form-data">
		<?php echo csrf_field(); ?>
        <input type="hidden" id="orden" name="orden" value="<?php echo e($orden); ?>" >
		<div class="form-group row <?php echo e($errors->has('nombre') ? ' has-warning' : ''); ?>">
            <label for="example-text-input" class="col-sm-4 col-form-label" for="nombre">
                Nombres
            </label>
            <div class="col-sm-8">
            	<input class="form-control <?php echo e($errors->has('nombre') ? ' form-control-warning' : ''); ?>" type="text" id="nombre" name="nombre" value="<?php echo e(old('nombre')); ?>" >
                <?php if($errors->has('nombre')): ?>
                    <div class="col-form-label">
                        <?php echo e($errors->first('nombre')); ?>

                    </div>
                <?php endif; ?>
            </div>
        </div>

        <div class="form-group row <?php echo e($errors->has('descripcion') ? ' has-warning' : ''); ?>">
            <label for="example-text-input" class="col-sm-4 col-form-label" for="descripcion">
                Descripción
            </label>
            <div class="col-sm-8">
            	<input class="form-control <?php echo e($errors->has('descripcion') ? ' form-control-warning' : ''); ?>" type="text" id="descripcion" name="descripcion" value="<?php echo e(old('descripcion')); ?>">
                <?php if($errors->has('descripcion')): ?>
                    <div class="col-form-label">
                        <?php echo e($errors->first('descripcion')); ?>

                    </div>
                <?php endif; ?>
            </div>
        </div>

        <div class="form-group row <?php echo e($errors->has('precio') ? ' has-warning' : ''); ?>">
            <label for="example-text-input" class="col-sm-4 col-form-label" for="precio">
                Precio
            </label>
            <div class="col-sm-8">
            	<input class="form-control <?php echo e($errors->has('precio') ? ' form-control-warning' : ''); ?>" type="number" id="precio" name="precio" value="<?php echo e(old('precio')); ?>">
                <?php if($errors->has('precio')): ?>
                    <div class="col-form-label">
                        <?php echo e($errors->first('precio')); ?>

                    </div>
                <?php endif; ?>
            </div>
        </div>

        <br>
        <br>
        <div class="col-sm-10 offset-sm-1">
            <div class="form-group row text-center">
                <div class="col-sm-6">
                    <button type="submit" class="btn btn-lg btn-warning waves-effect waves-light">
                        <i class="icofont icofont-save"></i> Guardar
                    </button>
                </div>
                <div class="col-sm-6">
                    <button type="reset" class="btn btn-lg btn-danger waves-effect waves-light">
                        <i class="icofont icofont-save"></i> Borrar
                    </button>
                </div>
            </div>
        </div>
	</form>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/js/select2.min.js"></script>
<script>
    $(document).ready(function() {
        $('.select2').select2();
    });

    $( ".select2" ).select2({
        theme: "bootstrap4"
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\yonei\Documents\projects\XRSoluciones\resources\views/admin/trabajos/crear.blade.php ENDPATH**/ ?>