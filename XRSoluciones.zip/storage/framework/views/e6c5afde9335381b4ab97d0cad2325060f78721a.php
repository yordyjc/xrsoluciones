<?php $__env->startSection('title'); ?>
Nuevo Conductor
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="card-body">
	<form action="<?php echo e(url('/admin/conductores/nuevo')); ?>" method="post" enctype="multipart/form-data">
		<?php echo csrf_field(); ?>
        <input type="hidden" id="cliente" name="cliente" value="<?php echo e($cliente->id); ?>" >
        <div class="form-group row">
            <label class="col-md-4 col-form-label" for="estado">
                Estado
            </label>
            <div class="col-md-8 form-radio">
                <div class="form-check-inline my-1">
                    <label>
                    <input type="radio" name="estado" id="estado" value="1" checked="checked">
                    <i class="helper"></i>Activo
                    </label>
                </div>
                <div class="form-check-inline my-1">
                    <label>
                    <input type="radio" name="estado" id="estado" value="0">
                    <i class="helper"></i>Suspendido
                    </label>
                </div>
            </div>
        </div>
		<div class="form-group row <?php echo e($errors->has('nombres') ? ' has-warning' : ''); ?>">
            <label for="example-text-input" class="col-sm-4 col-form-label" for="nombres">
                Nombres
            </label>
            <div class="col-sm-8">
            	<input class="form-control <?php echo e($errors->has('nombres') ? ' form-control-warning' : ''); ?>" type="text" id="nombres" name="nombres" value="<?php echo e(old('nombres')); ?>" >
                <?php if($errors->has('nombres')): ?>
                    <div class="col-form-label">
                        <?php echo e($errors->first('nombres')); ?>

                    </div>
                <?php endif; ?>
            </div>
        </div>
        <div class="form-group row <?php echo e($errors->has('apellidos') ? ' has-warning' : ''); ?>">
            <label for="example-text-input" class="col-sm-4 col-form-label" for="apellidos">
                Apellidos
            </label>
            <div class="col-sm-8">
            	<input class="form-control <?php echo e($errors->has('apellidos') ? ' form-control-warning' : ''); ?>" type="text" id="apellidos" name="apellidos" value="<?php echo e(old('apellidos')); ?>">
                <?php if($errors->has('apellidos')): ?>
                    <div class="col-form-label">
                        <?php echo e($errors->first('apellidos')); ?>

                    </div>
                <?php endif; ?>
            </div>
        </div>

        <div class="form-group row <?php echo e($errors->has('email') ? ' has-warning' : ''); ?>">
            <label for="example-text-input" class="col-sm-4 col-form-label" for="email">
                Email
            </label>
            <div class="col-sm-8">
            	<input class="form-control <?php echo e($errors->has('email') ? ' form-control-warning' : ''); ?>" type="text" id="email" name="email" value="<?php echo e(old('email')); ?>">
                <?php if($errors->has('email')): ?>
                    <div class="col-form-label">
                        <?php echo e($errors->first('email')); ?>

                    </div>
                <?php endif; ?>
            </div>
        </div>

        <div class="form-group row <?php echo e($errors->has('cel') ? ' has-warning' : ''); ?>">
            <label for="example-text-input" class="col-sm-4 col-form-label" for="cel">
                Celular
            </label>
            <div class="col-sm-8">
            	<input class="form-control <?php echo e($errors->has('cel') ? ' form-control-warning' : ''); ?>" type="text" id="cel" name="cel" value="<?php echo e(old('cel')); ?>">
                <?php if($errors->has('cel')): ?>
                    <div class="col-form-label">
                        <?php echo e($errors->first('cel')); ?>

                    </div>
                <?php endif; ?>
            </div>
        </div>

        <div class="form-group row <?php echo e($errors->has('doc') ? ' has-warning' : ''); ?>">
            <label for="example-text-input" class="col-sm-4 col-form-label" for="doc">
                Nº de Doc de identidad
            </label>
            <div class="col-sm-8">
            	<input class="form-control <?php echo e($errors->has('doc') ? ' form-control-warning' : ''); ?>" type="text" id="doc" name="doc" value="<?php echo e(old('doc')); ?>">
                <?php if($errors->has('doc')): ?>
                    <div class="col-form-label">
                        <?php echo e($errors->first('doc')); ?>

                    </div>
                <?php endif; ?>
            </div>
        </div>

        <div class="form-group row <?php echo e($errors->has('doc') ? ' has-warning' : ''); ?>">
            <label for="example-text-input" class="col-sm-4 col-form-label" for="licencia">
                Clase de licencia
            </label>
            <div class="col-sm-8">
                <select class="form-control <?php echo e($errors->has('licencia') ? ' form-control-warning' : ''); ?>" name="licencia" id="licencia">
                    <option value="">--Seleccione--</option>
                    <option value="1">A-I</option>
                    <option value="2">A-IIa</option>
                    <option value="3">A-IIb</option>
                    <option value="4">A-IIIa</option>
                    <option value="5">A-IIIb</option>
                    <option value="6">A-IIIc</option>
                    <option value="7">B-I</option>
                    <option value="8">B-IIa</option>
                    <option value="9">B-IIb</option>
                    <option value="10">B-IIc</option>
                </select>
                <?php if($errors->has('licencia')): ?>
                    <div class="col-form-label">
                        <?php echo e($errors->first('licencia')); ?>

                    </div>
                <?php endif; ?>
            </div>
        </div>

        <div class="form-group row <?php echo e($errors->has('caducidad') ? ' has-warning' : ''); ?>">
            <label for="example-text-input" class="col-sm-4 col-form-label" for="caducidad">
                Fecha de caducidad
            </label>
            <div class="col-sm-8">
            	<input class="form-control <?php echo e($errors->has('caducidad') ? ' form-control-warning' : ''); ?>" type="date" id="caducidad" name="caducidad" value="<?php echo e(old('caducidad')); ?>">
                <?php if($errors->has('caducidad')): ?>
                    <div class="col-form-label">
                        <?php echo e($errors->first('caducidad')); ?>

                    </div>
                <?php endif; ?>
            </div>
        </div>

        <div class="form-group row <?php echo e($errors->has('observaciones') ? ' has-warning' : ''); ?>">
            <label for="example-text-input" class="col-sm-4 col-form-label" for="observaciones">
                Observaciones
            </label>
            <div class="col-sm-8">
                <textarea row="10" class="form-control <?php echo e($errors->has('observaciones') ? ' form-control-warning' : ''); ?>" type="text" id="observaciones" name="observaciones"><?php echo e(old('observaciones')); ?></textarea>
                <?php if($errors->has('observaciones')): ?>
                    <div class="col-form-label">
                        <?php echo e($errors->first('observaciones')); ?>

                    </div>
                <?php endif; ?>
            </div>
        </div>




        <br>
        <br>
        <div class="col-sm-10 offset-sm-1">
            <div class="form-group row text-center">
                <div class="col-sm-6">
                    <button type="submit" class="btn btn-lg btn-warning waves-effect waves-light">
                        <i class="icofont icofont-save"></i> Guardar
                    </button>
                </div>
                <div class="col-sm-6">
                    <button type="reset" class="btn btn-lg btn-danger waves-effect waves-light">
                        <i class="icofont icofont-save"></i> Borrar
                    </button>
                </div>
            </div>
        </div>
	</form>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\yonei\Documents\projects\XRSoluciones\resources\views/admin/conductores/crear.blade.php ENDPATH**/ ?>