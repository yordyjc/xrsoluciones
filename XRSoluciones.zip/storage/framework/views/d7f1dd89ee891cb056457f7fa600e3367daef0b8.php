<?php echo Html::script("assets/js/jquery.min.js"); ?>

<?php echo Html::script("assets/js/popper.min.js"); ?>

<?php echo Html::script("assets/js/bootstrap.min.js"); ?>

<?php echo Html::script("assets/js/jquery.blockUI.js"); ?>

<?php echo Html::script("assets/js/jquery.nicescroll.js"); ?>

<?php echo Html::script("assets/js/jquery.scrollTo.min.js"); ?>

<?php echo Html::script("assets/js/jquery.slimscroll.js"); ?>

<?php echo Html::script("assets/js/modernizr.min.js"); ?>


<?php echo Html::script("assets/js/waves.js"); ?>

<?php echo Html::script("assets/js/detect.js"); ?>

<?php echo Html::script("assets/js/fastclick.js"); ?>


<?php echo Html::script("assets/plugins/skycons/skycons.min.js"); ?>

<?php echo Html::script("assets/plugins/raphael/raphael-min.js"); ?>

<?php echo Html::script("assets/plugins/morris/morris.min.js"); ?>

<?php echo Html::script("assets/pages/dashborad.js"); ?>


<?php echo Html::script("assets/plugins/datatables/jquery.dataTables.min.js"); ?>

<?php echo Html::script("assets/plugins/datatables/dataTables.bootstrap4.min.js"); ?>


<?php echo Html::script("assets/plugins/datatables/dataTables.buttons.min.js"); ?>

<?php echo Html::script("assets/plugins/datatables/buttons.bootstrap4.min.js"); ?>

<?php echo Html::script("assets/plugins/datatables/jszip.min.js"); ?>

<?php echo Html::script("assets/plugins/datatables/pdfmake.min.js"); ?>

<?php echo Html::script("assets/plugins/datatables/vfs_fonts.js"); ?>

<?php echo Html::script("assets/plugins/datatables/buttons.html5.min.js"); ?>

<?php echo Html::script("assets/plugins/datatables/buttons.print.min.js"); ?>

<?php echo Html::script("assets/plugins/datatables/buttons.colVis.min.js"); ?>


<?php echo Html::script("assets/plugins/datatables/responsive.bootstrap4.min.js"); ?>

<?php echo Html::script("assets/plugins/datatables/dataTables.responsive.min.js"); ?>


<?php echo Html::script("assets/plugins/datatables/dataTables.responsive.min.js"); ?>


<?php echo Html::script("assets/pages/datatables.init.js"); ?>




<?php echo Html::script("assets/plugins/datatables/jszip.min.js"); ?>




<?php echo Html::script("assets/plugins/jquery-ui/jquery-ui.min.js"); ?>


<?php echo Html::script("assets/plugins/select2/select2.min.js"); ?>

<?php echo Html::script("assets/js/app.js"); ?>

  <script>
    /* BEGIN SVG WEATHER ICON */
                 if (typeof Skycons !== 'undefined'){
                var icons = new Skycons(
                    {"color": "#fff"},
                    {"resizeClear": true}
                    ),
                        list  = [
                            "clear-day", "clear-night", "partly-cloudy-day",
                            "partly-cloudy-night", "cloudy", "rain", "sleet", "snow", "wind",
                            "fog"
                        ],
                        i;
    
                    for(i = list.length; i--; )
                    icons.set(list[i], list[i]);
                    icons.play();
                };
    
            // scroll
    
            $(document).ready(function() {
            
            $("#boxscroll").niceScroll({cursorborder:"",cursorcolor:"#cecece",boxzoom:true});
            $("#boxscroll2").niceScroll({cursorborder:"",cursorcolor:"#cecece",boxzoom:true}); 
            
            });
  </script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/6.6.9/sweetalert2.min.js"></script>
<?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldContent('js'); ?><?php /**PATH C:\Users\yonei\Documents\projects\XRSoluciones\resources\views/includes/js.blade.php ENDPATH**/ ?>