{!!Html::style("assets/plugins/morris/morris.css")!!}

{!!Html::style("assets/css/bootstrap.min.css")!!}
{!!Html::style("assets/css/icons.css")!!}

{!!Html::style("assets/plugins/datatables/buttons.bootstrap4.min.css")!!}
{!!Html::style("assets/plugins/datatables/dataTables.bootstrap4.min.css")!!}
{!!Html::style("assets/plugins/datatables/responsive.bootstrap4.min.css")!!}

{!!Html::style("assets/plugins/select2/select2.min.css")!!}

{!!Html::style("assets/icons/feather2/css/feather.css")!!}
{!!Html::style("assets/css/style.css")!!}
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/6.6.9/sweetalert2.min.css">
@yield('css')