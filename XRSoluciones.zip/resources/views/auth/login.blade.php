<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width,initial-scale=1,user-scalable=0,minimal-ui">
  <title>XR Soluciones</title>
  <meta content="Admin Dashboard" name="description">
  <meta content="Mannatthemes" name="author">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <link href="assets/css/bootstrap.min.css" rel="stylesheet" type="text/css">
  <link href="assets/css/icons.css" rel="stylesheet" type="text/css">
  <link href="assets/css/style.css" rel="stylesheet" type="text/css">
</head>

<body class="fixed-left">
  <!-- Begin page -->
  <div class="accountbg"></div>
  <div class="wrapper-page">
    <div class="card">
      <div class="card-body">
        <h3 class="text-center mt-0 m-b-15">
          <a href="#" class="logo logo-admin"><img src="assets/images/logo.png"  alt="logo" width="250px"></a>
        </h3>
        <div class="p-3">
          <form class="form-horizontal m-t-20" action="{{route('login')}}" method="POST">
            @csrf
            <div class="form-group row">
                <div class="col-12"><input class="form-control {{$errors->has('email') ? ' form-control-danger' : ''}}" name="email" value="{{old('email')}}" id="email" type="text" required="" placeholder="Username"></div>
                @if ($errors->has('email'))
                    <div class="has-danger">
                        <div class="col-form-label">
                            {{ $errors->first('email') }}
                        </div>
                    </div>
                @endif
            </div>
            <div class="form-group row">
              <div class="col-12"><input class="form-control {{ $errors->has('password') ? ' form-control-danger' : '' }}" id="password" name="password" type="password" required="" placeholder="Password"></div>
                @if ($errors->has('password'))
                    <div class="has-danger">
                        <div class="col-form-label">
                            {{ $errors->first('password') }}
                        </div>
                    </div>
                @endif
            </div>
            <div class="form-group row">
              <div class="col-12">
                <div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="customCheck1"> <label class="custom-control-label" for="customCheck1">Remember me</label></div>
              </div>
            </div>
            <div class="form-group text-center row m-t-20">
              <div class="col-12"><button class="btn btn-warning btn-block waves-effect waves-light" type="submit">Iniciar sesión</button></div>
            </div>
            <div class="form-group m-t-10 mb-0 row">
              <div class="col-sm-7 m-t-20"><a href="#" class="text-muted"><i class="mdi mdi-lock"></i> <small>Olvidaste tu contraseña ?</small></a></div>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
  <!-- jQuery  -->
  <script src="assets/js/jquery.min.js"></script>
  <script src="assets/js/popper.min.js"></script>
  <script src="assets/js/bootstrap.min.js"></script>
  <script src="assets/js/modernizr.min.js"></script>
  <script src="assets/js/detect.js"></script>
  <script src="assets/js/fastclick.js"></script>
  <script src="assets/js/jquery.slimscroll.js"></script>
  <script src="assets/js/jquery.blockUI.js"></script>
  <script src="assets/js/waves.js"></script>
  <script src="assets/js/jquery.nicescroll.js"></script>
  <script src="assets/js/jquery.scrollTo.min.js"></script>
  <!-- App js -->
  <script src="assets/js/app.js"></script>
</body>
<!-- Mirrored from mannatthemes.com/annex/vertical/pages-login.html by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 10 Aug 2020 22:49:53 GMT -->

</html>
